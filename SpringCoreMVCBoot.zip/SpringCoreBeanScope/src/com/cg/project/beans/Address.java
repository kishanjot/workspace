package com.cg.project.beans;

import java.util.Objects;

public class Address {
private String city,country;
private int pincode;
private String state;

public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public int getPincode() {
	return pincode;
}
public void setPincode(int pincode) {
	this.pincode = pincode;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
@Override
public String toString() {
	return "Address [city=" + city + ", country=" + country + ", pincode=" + pincode + ", state=" + state + "]";
}
@Override
public int hashCode() {
	return Objects.hash(city, country, pincode, state);
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Address other = (Address) obj;
	return Objects.equals(city, other.city) && Objects.equals(country, other.country) && pincode == other.pincode
			&& Objects.equals(state, other.state);
}

}
