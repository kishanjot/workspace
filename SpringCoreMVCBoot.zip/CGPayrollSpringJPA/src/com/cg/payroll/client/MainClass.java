package com.cg.payroll.client;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
public static void main(String[] args) {
		//PayrollServices services=new PayrollServicesImpl();
		
		ApplicationContext context=new ClassPathXmlApplicationContext("payrollBeans.xml");
		PayrollServices payrollServices=(PayrollServices) context.getBean("payrollServices");
		
		
		/*String firstName, String lastName, String emailId, String department,
		String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
		int accountNumber, String bankName, String ifscCode)*/
		
		int associateId1=payrollServices.acceptAssociateDetails("Kishanjot", "Singh", "kishanjot321@gmail.com" ,"TA", "Analyst", "PAC",22000, 30000, 1400, 1800, 4578, "CItiBank", "CITI0000005");
		//int associateId2=services.acceptAssociateDetails("Honey", "Singh", "Honey445@gmail.com" ,"XYZ", "CEO", "AB001", 7000, 35000, 1000, 1090, 3450, "RBI", "RBI001");
		//int associateId3=services.acceptAssociateDetails("Hun", "Singh", "Honey5445@gmail.com" ,"XYZ", "CEO", "AB001", 7000, 35000, 1000, 1090, 3450, "RBI", "RBI001");
		System.out.println("Associate Id 1:- "+associateId1);
	//System.out.println("Associate Id 2:- "+associateId2);
		
		//System.out.println("Associate Id 3:- "+associateId3);
		//System.out.println(services.getAllAssociatesDetails());
	   // System.out.println(services.calculateNetSalary(8));
		/*
		try {
			System.out.println(services.getAssociateDetails(101));
		} catch (AssociateDetailsNotfoundException ae) {
			System.out.println(ae.getMessage());
		}
		*/
	   
	}
}
