package com.cg.banking.main;
import java.util.Scanner;

import javax.crypto.spec.IvParameterSpec;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
public class MainClass {
	public static void main(String[] args)
	{
		char continueChoice='y';
		Scanner scan=new Scanner(System.in);
		BankingServicesImpl bankingService=new BankingServicesImpl();
		
		do {
		{
		System.out.println("Enter your choice : ");
		System.out.println("Press 1 to open new account \n Press 2 to deposit money in your account"
				+ "\n Press 3 to withdraw money from your account \nPress 4 to transfer funds to another account"
				+ " \nPress 5 to get your account details \nPress 6 to Get All Transactions Details");
		int choice=scan.nextInt();
		switch (choice)
		{
		case 1:
		{
		System.out.println("Enter type of account (Savings /Current:)");
		String accountType=scan.next();
		System.out.println("Enter initial balance: ");
		float initialBalance=scan.nextFloat();
		try {
		System.out.println(bankingService.openAccount(accountType,initialBalance)); 
		}
		catch(InvalidAccountTypeException e) {
		System.out.println("Account Type is Invalid, Please Enter either 'SAVINGS' or 'CURRENT'");}
		break;
		}
		
		case 2:
		{
			System.out.println("Enter your account number:");
			long accNumber=scan.nextLong();
			System.out.println("Enter amount to deposit: ");
			float amt=scan.nextFloat();
			try {
			System.out.println(bankingService.depositAmount(accNumber, amt));}
			catch(AccountNotFoundException e){
				System.out.println("Incorrect Account Number,Please Try Again");}
			catch(InsufficientAmountException e) {
				System.out.println("Please Enter Amount Greater Than 500");}
			catch(InvalidAmountException e) {
			System.out.println("Please Enter Valid Amount Only");}
			break;
		}
		case 3:
		{
			System.out.println("Enter your account number:");
			long accNumber=scan.nextLong();
			System.out.println("Enter amount to withdraw: ");
			float amt=scan.nextFloat();
			System.out.println("Enter pin: ");
			int pinNumber=scan.nextInt();
			try {
			System.out.println(bankingService.withdrawAmount(accNumber, amt,pinNumber));
			}
			catch(InvalidPinNumberException e){
			System.out.println("Invalid Pin , Please Try Again");}
			catch(AccountNotFoundException e){
				System.out.println("Account Not Found , Please Try Again");}
			/*
			catch(AccountBlockedException e){
				System.out.println("Blocked");
				}*/
			break;
		}
		case 4:
		{
			System.out.println("Enter your account number: ");
			long fromAcc=scan.nextLong();
			System.out.println("Enter account number to deposit: ");
			long toAcc=scan.nextLong();
			System.out.println("Enter amount: ");
			float transfer=scan.nextFloat();
			System.out.println("Enter pin : ");
			int pinNumber=scan.nextInt();
			try {
			System.out.println(bankingService.fundTransfer(toAcc, fromAcc, transfer, pinNumber));
			}
			catch (AccountNotFoundException e) {
				System.out.println("Account No Incorrect, Try Again");}
			catch (InvalidPinNumberException e) {
				System.out.println("Pin Not Correct, Try Again");}
			catch (InvalidAmountException e) {
				System.out.println("Amount Invalid, Try Again");}
			
			break;
		}
		case 5:
		{
			System.out.println("Enter your account number:");
			long accNumber=scan.nextLong();
			try {
			System.out.println(bankingService.getAccountDetails(accNumber));}
			catch(AccountNotFoundException e) {
			System.out.println("Account Not Found,Please Try Again Later");}
			break;
		}
		case 6 :
		{
			System.out.println(" You'll Get Transaction Details, Press 1 to Enter");
			long accNumber=scan.nextLong();
			System.out.println(bankingService.getAccountAllTransaction(accNumber));
		}
		default:
			System.out.println("Wrong choice");
		
		}
		System.out.println("Do You Want To Continue Further ? (yes/no)");
		continueChoice=scan.next().charAt(0);
		}
		}
		while(continueChoice=='y'||continueChoice=='Y');
		
	}
		
	}   

			
			