package com.cg.project.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.pagebeans.PageBeans;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegStepDef {
	private WebDriver driver;
	private PageBeans pageBean;
	
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\3000172_Kishanjot_Singh\\BDDCucumberSelenium\\chromedriver.exe" );
		driver=new ChromeDriver();	
	}
	
	//User wants to register
	@Given("^user is on the registration page$")
	public void user_is_on_the_registration_page() throws Throwable {
		driver.get("D:\\BDDMPTHTMfiles\\Set B\\ConferenceRegistartion.html");
		pageBean = PageFactory.initElements(driver, PageBeans.class);
	}

	@Then("^check the title of the registration page$")
	public void check_the_title_of_the_registration_page() throws Throwable {
		if(driver.getTitle().equals("Conference Registartion")) 
			System.out.println("TestCase :1\n**** Title Matched");
		else
			System.out.println("**** Title Not Matched");
	}
//leaves first name empty
	@When("^user leaves First Name blank and submit$")
	public void user_leaves_First_Name_blank_and_submit() throws Throwable {
		pageBean.setPffName("");
		pageBean.setPfSubmit();
	}
//alert box will display
	@Then("^display alert box with first name empty message$")
	public void display_alert_box_with_first_name_empty_message() throws Throwable {
		driver.switchTo().alert().dismiss();
	
	}
//leaves last name blank
	@When("^user leaves Last Name blank and submit$")
	public void user_leaves_Last_Name_blank_and_submit() throws Throwable {
		pageBean.setPffName("Kish");
		pageBean.setPflName("");
		pageBean.setPfSubmit();
	}
	//alert box will display
	@Then("^display alert box with last name empty message$")
	public void display_alert_box_with_last_name_empty_message() throws Throwable {
		driver.switchTo().alert().dismiss();
	
	}
//leaves email blank
	@When("^user leaves email blank and submit$")
	public void user_leaves_email_blank_and_submit() throws Throwable {
		pageBean.setPffName("Kish");
		pageBean.setPflName("Singh");
		pageBean.setPfEmail("");
		pageBean.setPfSubmit();
	}
	//alert box will display
	@Then("^display alert box with email empty message$")
	public void display_alert_box_with_email_empty_message() throws Throwable {
		driver.switchTo().alert().dismiss();
	}
//enter wrong email format
	@When("^user enters wrong email format and submit$")
	public void user_enters_wrong_email_format_and_submit() throws Throwable {
		pageBean.setPffName("Kish");
		pageBean.setPflName("Singh");
		pageBean.setPfEmail("kjgmailcom");
		pageBean.setPfSubmit();
	}
	//alert box will display
	@Then("^display alert box with wrong email format message$")
	public void display_alert_box_with_wrong_email_format_message() throws Throwable {
		driver.switchTo().alert().dismiss();
	}
//blank contact no
	@When("^user leaves contact no blank and submit$")
	public void user_leaves_contact_no_blank_and_submit() throws Throwable {
		pageBean.setPffName("Kish");
		pageBean.setPflName("Singh");
		pageBean.setPfEmail("kj@gmail.com");
		pageBean.setPfPhoneNo("");
		pageBean.setPfSubmit();
	}
	//alert box will display
	@Then("^display alert box with contact empty message$")
	public void display_alert_box_with_contact_empty_message() throws Throwable {
		driver.switchTo().alert().dismiss();
	}

	@When("^user enters wrong contact no format and submit$")
	public void user_enters_wrong_contact_no_format_and_submit() throws Throwable {
		pageBean.setPffName("Kish");
		pageBean.setPflName("Singh");
		pageBean.setPfEmail("kj@gmail.com");
		pageBean.setPfPhoneNo("45514");
		pageBean.setPfSubmit();
	}
	//alert box will display
	@Then("^display alert box with wrong contact no format message$")
	public void display_alert_box_with_wrong_contact_no_format_message() throws Throwable {
		driver.switchTo().alert().dismiss();
	}

	@When("^user leaves number of people attending blank and submit$")
	public void user_leaves_number_of_people_attending_blank_and_submit() throws Throwable {
		pageBean.setPffName("Kish");
		pageBean.setPflName("Singh");
		pageBean.setPfEmail("kj@gmail.com");
		pageBean.setPfPhoneNo("45514");
		pageBean.setPfNoOfPeopleAttending("");
		pageBean.setPfSubmit();
	}
	//alert box will display
	@Then("^display alert box with empty number of people attending$")
	public void display_alert_box_with_empty_number_of_people_attending() throws Throwable {
		driver.switchTo().alert().dismiss();
	}

	@When("^user leaves building and room no blank and submit$")
	public void user_leaves_building_and_room_no_blank_and_submit() throws Throwable {
		pageBean.setPffName("Kish");
		pageBean.setPflName("Singh");
		pageBean.setPfEmail("kj@gmail.com");
		pageBean.setPfPhoneNo("45514");
		pageBean.setPfNoOfPeopleAttending("2");
		pageBean.setPfBuildNameRoomNo("");
		pageBean.setPfSubmit();
	}
	//alert box will display
	@Then("^display alert box with building and room no empty message$")
	public void display_alert_box_with_building_and_room_no_empty_message() throws Throwable {
		driver.switchTo().alert().dismiss();
	}

	@When("^user leaves area name blank and submit$")
	public void user_leaves_area_name_blank_and_submit() throws Throwable {
		pageBean.setPffName("Kish");
		pageBean.setPflName("Singh");
		pageBean.setPfEmail("kj@gmail.com");
		pageBean.setPfPhoneNo("45514");
		pageBean.setPfNoOfPeopleAttending("2");
		pageBean.setPfBuildNameRoomNo("C No 11, D No 45");
		pageBean.setPfAreaName("");
		pageBean.setPfSubmit();
	}
	//alert box will display
	@Then("^display alert box with area name empty message$")
	public void display_alert_box_with_area_name_empty_message() throws Throwable {
		driver.switchTo().alert().dismiss();
	}

	@When("^user leaves city name blank and submit$")
	public void user_leaves_city_name_blank_and_submit() throws Throwable {
		pageBean.setPffName("Kish");
		pageBean.setPflName("Singh");
		pageBean.setPfEmail("kj@gmail.com");
		pageBean.setPfPhoneNo("45514");
		pageBean.setPfNoOfPeopleAttending("2");
		pageBean.setPfBuildNameRoomNo("C No 11, D No 45");
		pageBean.setPfAreaName("KP");
		pageBean.setPfSubmit();
	}
	//alert box will display
	@Then("^display alert box with city name empty message$")
	public void display_alert_box_with_city_name_empty_message() throws Throwable {
		driver.switchTo().alert().dismiss();
	}

	@When("^user leaves state column blank and submit$")
	public void user_leaves_state_column_blank_and_submit() throws Throwable {
		pageBean.setPffName("Kish");
		pageBean.setPflName("Singh");
		pageBean.setPfEmail("kj@gmail.com");
		pageBean.setPfPhoneNo("45514");
		pageBean.setPfNoOfPeopleAttending("2");
		pageBean.setPfBuildNameRoomNo("C No 11, D No 45");
		pageBean.setPfAreaName("KP");
		pageBean.setPfCity("Pune");
		pageBean.setPfSubmit();
	}
	//alert box will display
	@Then("^display alert box with state column empty message$")
	public void display_alert_box_with_state_column_empty_message() throws Throwable {
		driver.switchTo().alert().dismiss();
	}

	@When("^user leaves membership status blank and submit$")
	public void user_leaves_membership_status_blank_and_submit() throws Throwable {
		pageBean.setPffName("Kish");
		pageBean.setPflName("Singh");
		pageBean.setPfEmail("kj@gmail.com");
		pageBean.setPfPhoneNo("45514");
		pageBean.setPfNoOfPeopleAttending("2");
		pageBean.setPfBuildNameRoomNo("C No 11, D No 45");
		pageBean.setPfAreaName("KP");
		pageBean.setPfCity("Pune");
		pageBean.setPfState("Maharashtra");
		pageBean.setPfSubmit();
	}
	//alert box will display
	@Then("^display alert box with membership status empty message$")
	public void display_alert_box_with_membership_status_empty_message() throws Throwable {
		driver.switchTo().alert().dismiss();
	}
//all valid details
	@When("^user enters vall valid data and submit$")
	public void user_enters_vall_valid_data_and_submit() throws Throwable {
		pageBean.setPffName("Kish");
		pageBean.setPflName("Singh");
		pageBean.setPfEmail("kj@gmail.com");
		pageBean.setPfPhoneNo("45514");
		pageBean.setPfNoOfPeopleAttending("2");
		pageBean.setPfBuildNameRoomNo("C No 11, D No 45");
		pageBean.setPfAreaName("KP");
		pageBean.setPfCity("Pune");
		pageBean.setPfState("Maharashtra");
		pageBean.setPfMembershipStatus("1");
		pageBean.setPfSubmit();
	}
	//alert box will display
	@Then("^display alert box with registration success message$")
	public void display_alert_box_with_registration_success_message() throws Throwable {
		driver.switchTo().alert().dismiss();
	}

	
	  @Then("^navigate to payment page$") public void navigate_to_payment_page()
	  throws Throwable {
	  driver.navigate().to("D:\\BDDMPTHTMfiles\\Set B\\PaymentDetails.html"); }
	 
	
	@After
	public void closeBrowser() {
		driver.close();
	}
}
