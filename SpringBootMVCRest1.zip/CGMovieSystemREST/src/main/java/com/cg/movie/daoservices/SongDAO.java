package com.cg.movie.daoservices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.movie.beans.Song;

public interface SongDAO extends JpaRepository<Song,Integer>{
	
	@Query("from Song s where s.movie.movieId=:movieId")
	List<Song> findAllMovieSongs(@Param("movieId")int movieId);
	
}
