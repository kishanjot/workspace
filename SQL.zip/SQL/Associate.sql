create table Associate(
associateId number,
firstName varchar2(50) not null,
lastName varchar2(50) not null,
yearlyInvestmentUnder80C number,
department varchar2(50) not null,
designation varchar2(50) not null,
pancard varchar2(50) not null,
emailId varchar2(50) not null
)
--------------------------------------------------------
drop table Associate
-------------------------------------------------------
alter table Associate
add constraint PK_AssociateID
primary key(associateId)
-------------------------------------------------------
alter table Associate
add constraint UK_EmailId
unique(emailId)
------------------------------------------------------
CREATE TABLE SALARY(
BASICSALARY NUMBER,

------------------------------------------------
select * from Associate

------------
create table Salary(
associateId number,
basicsalary number,
hra number,
conveyenceallowance number,
otherallowance number,
personalallowance number,
monthlytax number,
epf number,
companypf number,
grosssalary number,
netsalary number
)
-----------------------
create table BankDetails(
accoutnumber number,
bankname varchar2(50),
ifsccode varchar2(50)
)
----------
drop table salary
drop table BankDetails
---------------------
alter table Salary
add constraint FK_AssociateID
foreign key(associateId) REFERENCES Associate(associateId)
-------------------
create table BankDetails(
associateId number constraint FK_AssociateID REFERENCES Associate(associateId),
accountNumber number,
bankName varchar2(50),
isfcCode varchar2(50)
}
-------------
select *
from Associate
where firstName like'%s%'
------
select *
from Associate
where yearlyinvestmentunder80c <90000 and yearlyinvestmentunder80c >10000
---------
select *
from Associate
where YEARLYINVESTMENTUNDER80C between 10000 and 90000
----------
select *
from Associate
where yearlyinvestmentunder80c IN(10000,20000,70000)
-------
select count(*)"Total No Of Associate"
from Associate
-----
select sysdate
From dual;

select add_months(sysdate,2)
FROM dual;

select months_between(sysdate,'01-sep-2018')
FROM dual;

select extract(year FROM sysdate)
FROM dual;

select extract(month FROM date'2011-04-01')
FROM dual;

select extract (month from book_issue_date)
FROM book_transaction;
----------
SELECT TO_CHAR (SYSDATE,'DD month,YYYY')FROM dual;   //your wish to put colunn or captial letters

SELECT TO_CHAR (SYSDATE,'DDth month,YYYY')FROM dual;

SELECT TO_CHAR (17000,'$99,999.00')FROM dual;

----------
select a.associateId,a.firstName,a.lastName,s.basicSalary,s.netSalary,b.bankName
from Associate a,Salary s,BankDetails b
---
select a.associateId,a.firstName,a.lastName,s.basicSalary,s.netSalary,b.bankName
from Associate a,Salary s,BankDetails b
where a.associateId=s.associateId and a.associateId=b.associateId;   //selfequijoin
-------------------------------------
select a.associateId,a.firstName,a.lastName,s.basicSalary,s.netSalary,b.bankName
from Associate a,Salary s,BankDetails b
where a.associateId(+)=s.associateId;               //leftjoin
-------

create view AssociateBankDetails
AS
select a.associateId,a.firstName,a.lastName,b.bankName,b.ifscCode
from Associate a,BankDetails b
where a.associateId=b.associateId

select * from AssociateBankDetails

-----------------

SET SERVEROUTPUT ON

begin
DBMS_OUTPUT.PUT_LINE('Welcome');
END;
---------
DECLARE
weName VARCHAR2(20)NOT NULL:='Kishanjot';
id NUMBER;
BEGIN
weNAME:='Kishanjot';
DBMS_OUTPUT.PUT_LINE(weName||''||id);
END;
----------
DECLARE
aId number;
fName varchar(50);
lName varchar(50);
begin
select associateId,firstName,lastName INTO aID,fName,lName
from Associate
where associateId=&aId;
DBMS_OUTPUT.PUT_LINE(aId||''||fName||''||lName);
end;
-----------
DECLARE 
aId ASSOCIATE.ASSOCIATEID%TYPE;
fName ASSOCIATE.FIRSTNAME%TYPE;
lName ASSOCIATE.LASTNAME%TYPE;
BEGIN
SELECT associateID,firstName,lastName INTO aId,fName,Lname
from Associate 
where associateID=&aId;
DBMS_OUTPUT.PUT_LINE(aId||' '||fName||' '||lName);
END;
----------------
DECLARE
assciateRow ASSOCIATE%ROWTYPE;
begin
select* INTO associateRow
from Associate
where associateId=&aId;
DBMS_OUTPUT.PUT_LINE(associateRow.ASSOCIATEID);
end;
----------
DECLARE
CURSOR associateCursor IS 
select * from Associate;
associateRow ASSOCIATE%ROWTYPE;
begin
OPEN associateCursor;
LOOP
FETCH associateCursor INTO associateRow;
DBMS_OUTPUT.PUT_LINE(associateRow.ASSOCIATEID||' '||associateRow.firstName||' '||associateROw.lastName);
EXIT WHEN associateCursor%NOTFOUND;
END LOOP;
CLOSE associateCursor;
end;
-------------------------------
DECLARE
aid Number;
fName varchar(20);
lName varchar(20);
begin
SELECT associateID,firstName,lastName INTO aId,fName,Lname
from Associate 
where associateID=&aId;
DBMS_OUTPUT.PUT_LINE(aId||' '||fName||' '||lName);
EXCEPTION
WHEN NO_DATA_FOUND THEN
DBMS_OUTPUT.PUT_LINE('No employee found');
WHEN TOO_MANY_ROWS THEN
DBMS_OUTPUT.PUT_LINE('Too many records found');
end;
---------------
DECLARE 
CURSOR associateCursor is select * from Associate
where yearlyinvestmentUnder80c>=&yearlyinvestmentUnder80c;
associateRow ASSOCIATE%ROWTYPE;
No_record_found Exception;
BEGIN
OPEN associateCursor;

FETCH associateCursor INTO associateRow;

if associateCursor%Rowcount>0
then 
loop
FETCH associateCursor INTO associateRow;
DBMS_OUTPUT.PUT_LINE(associateRow.ASSOCIATEID||' '||associateRow.firstName||' '||associateRow.lastName);
EXIT WHEN associateCursor%NOTFOUND;
END LOOP;
else
raise No_record_found;
end if;
CLOSE associateCursor;
exception
when No_record_found then
DBMS_OUTPUT.PUT_LINE('Not Found');
end;
---------------------
CREATE SEQUENCE ASSOCIATE_ID_SEQ
START WITH 1

--------------------------
