package com.cg.project.beans;

public class Associate {
private int associateId;
private String firstName,lastName,attribute,emailId,department,designation,password,
panCard;
// private List<String>contact;

public Associate(int associateId, String password) {
	super();
	this.associateId = associateId;
	this.password = password;
}
public Associate(int associateId, String firstName, String lastName, String attribute, String emailId,
		String department, String designation, String password, String panCard) {
	super();
	this.associateId = associateId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.attribute = attribute;
	this.emailId = emailId;
	this.department = department;
	this.designation = designation;
	this.password = password;
	this.panCard = panCard;
}
public int getAssociateId() {
	return associateId;
}
public void setAssociateId(int associateId) {
	this.associateId = associateId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getAttribute() {
	return attribute;
}
public void setAttribute(String attribute) {
	this.attribute = attribute;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getPanCard() {
	return panCard;
}
public void setPanCard(String panCard) {
	this.panCard = panCard;
}
@Override
public String toString() {
	return "Associate [associateId=" + associateId + ", firstName=" + firstName + ", lastName=" + lastName
			+ ", attribute=" + attribute + ", emailId=" + emailId + ", department=" + department + ", designation="
			+ designation + ", password=" + password + ", panCard=" + panCard + "]";
}




}
