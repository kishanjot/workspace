function validateLoginForm(){
    if(loginForm.associateId.value==""){
        alert("Enter associateId");
        return false;
    }
    else if(loginForm.password.value==""){
        alert("Enter password");
        return false;
    }
}
function validateRegistrationForm(){
    if(registerForm.firstName.value==""){
        alert("Enter first name");
        return false;
    }
    else if(registerForm.lastName.value==""){
        alert("Enter last name");
        return false;
    }
    else if(registerForm.emailId.value==""){
        alert("Enter emailid");
        return false;
    }
    else if(registerForm.department.value==""){
        alert("Enter department value");
        return false;
    }
    else if(registerForm.designation.value==""){
        alert("Enter designation");
        return false;
    }
    else if(registerForm.accountNumber.value==""){
        alert("Enter account number")
        return false;
    }
    else if(registerForm.panCard.value==""){
        alert("Enter panCard")
        return false;
    }
    else if(registerForm.bankName.value==""){
        alert("Enter bankName")
        return false;
    }
    else if(registerForm.ifscCode.value==""){
        alert("Enter ifsc code")
        return false;
    }
    else if(registerForm.accountNumber.value==""){
        alert("Enter account number")
        return false;
    }
}
function checkSame(){
    if(changePasswordForm.password.value!=changePasswordForm.confirmPassword.value){
        alert("Password not matched")
        return false;
    }
}
function validatePassword(){
    if(changePasswordForm.password.value.length>=6){
        if(changePasswordForm.password.value.search(/[0-9]/)!=-1 &&
                changePasswordForm.password.value.search(/[A-Z]/)!=-1 &&
                changePasswordForm.password.value.search(/[!@#$%^&*()_+]/)!=-1){
            return true;
        }
        else{
            alert("password must contain atleast 1 number,1 uppercase letter and 1 lowercase letter");
            return false;
        }
    }
    else{
        alert("minimum 6f 6 characters");
        return false;
    }
}