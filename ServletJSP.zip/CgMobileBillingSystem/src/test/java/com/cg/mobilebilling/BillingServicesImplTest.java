package com.cg.mobilebilling;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAOServices;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
import com.cg.mobilebilling.services.BillingServicesImpl;

public class BillingServicesImplTest {

	public static BillingServices billingServicesPlan;
	public static BillingServices billingServicesCustomer;
	public static BillingServices billingServicesPostpaid;
	public static BillingServices billingServicesBill;
	private static PlanDAOServices mockPlanDAOService;
	private static CustomerDAOServices mockCustomerDAOService;
	private static PostpaidAccountDAOServices mockPostpaidAccountDAOService;
	private static BillingDAOServices mockBillingDAOServices;
	
	Customer customer ;
	PostpaidAccount postpaidAccount;
	List<Plan> plans;
	Plan plan1,plan2;
	Address address1,address2;
	PostpaidAccount postpaidAccount1,postpaidAccount2;
	Bill bill1,bill2,bill3;
	Map<Integer, Bill> bills1,bills2;
	List<Customer> customers;
	Map<Long, PostpaidAccount> postpaidAccounts;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		mockPlanDAOService = EasyMock.createMock(PlanDAOServices.class);
		billingServicesPlan = new BillingServicesImpl(mockPlanDAOService);
		mockCustomerDAOService = EasyMock.createMock(CustomerDAOServices.class);
		billingServicesCustomer = new BillingServicesImpl(mockCustomerDAOService);
		mockPostpaidAccountDAOService = EasyMock.createMock(PostpaidAccountDAOServices.class);
		billingServicesPostpaid = new BillingServicesImpl(mockPostpaidAccountDAOService);
		mockBillingDAOServices = EasyMock.createMock(BillingDAOServices.class);
		billingServicesBill = new BillingServicesImpl(mockBillingDAOServices);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {

		billingServicesPlan=null;
		billingServicesCustomer=null;
		billingServicesPostpaid=null;
		billingServicesBill=null;
		mockPlanDAOService=null;
		mockCustomerDAOService=null;
		mockPostpaidAccountDAOService=null;
		mockBillingDAOServices=null;

	}

	@Before
	public void setUp() throws Exception {
		plan1=new Plan(150, 100, 100, 100, 100, 1024, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f, "bihar/jharkhand", "Diwali offer");
		plan2=new Plan(250, 200, 200, 200, 200, 2048, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f, "pune", "Super offer");
		plans = new ArrayList<>();
		plans.add(plan1);
		plans.add(plan2);

		 customer = new Customer(1001, "Sushant", "Dey", "sushant@gmail.com", "15-04-1996", null, null);
		 address1 = new Address(831002, "Jamshedpur", "Jharkhand");
		customer.setBillingAddress(address1);
		
		postpaidAccount1 = new PostpaidAccount(700430840, plan1,null);
		postpaidAccount2 = new PostpaidAccount(809243332, plan2, null);

		bill1 = new Bill(1, 100, 100, 100, 100, 1000, "January", 172, 0, 0, 0, 0, 0, 15, 7, postpaidAccount1);
		bill2 = new Bill(2, 100, 100, 100, 100, 1000, "February", 172, 0, 0, 0, 0, 0, 15, 7, postpaidAccount1);
		bill3 = new Bill(3, 100, 100, 100, 100, 1000, "March", 172, 0, 0, 0, 0, 0, 15, 7, postpaidAccount2);
		bills1=new LinkedHashMap<>();
		bills2=new LinkedHashMap<>();
		bills1.put(1, bill1);
		bills1.put(2, bill2);
		bills2.put(1, bill3);

		postpaidAccount1.setBills(bills1);
		postpaidAccount2.setBills(bills2);
		postpaidAccounts=new LinkedHashMap<>();
		postpaidAccounts.put(postpaidAccount1.getMobileNo(), postpaidAccount1);
		postpaidAccounts.put( postpaidAccount2.getMobileNo(), postpaidAccount2);
		customers=new ArrayList<>();
		customer.setPostpaidAccounts(postpaidAccounts);
		customers.add(customer);
		
		EasyMock.expect(mockPlanDAOService.findAll()).andReturn(plans);
		EasyMock.replay(mockPlanDAOService);
		EasyMock.expect(mockCustomerDAOService.save(EasyMock.isA(Customer.class))).andReturn(customer);
		EasyMock.replay(mockCustomerDAOService);
		EasyMock.expect(mockCustomerDAOService.findById(EasyMock.isA(Integer.class)).get()).andReturn(customer);
		EasyMock.replay(mockCustomerDAOService);
		EasyMock.expect(mockPostpaidAccountDAOService.save(EasyMock.isA(PostpaidAccount.class))).andReturn(postpaidAccount);
		EasyMock.replay(mockPostpaidAccountDAOService);
		EasyMock.expect(mockPlanDAOService.findById(EasyMock.isA(Integer.class)).get()).andReturn(plan1);
		EasyMock.replay(mockPlanDAOService);
		EasyMock.expect(mockPostpaidAccountDAOService.findById(EasyMock.isA(Long.class)).get()).andReturn(postpaidAccount);
		EasyMock.replay(mockPostpaidAccountDAOService);
		EasyMock.expect(mockBillingDAOServices.save(EasyMock.isA(Bill.class))).andReturn(bill1);
		EasyMock.replay(mockBillingDAOServices);
		EasyMock.expect(mockCustomerDAOService.findAll()).andReturn(customers);
		EasyMock.replay(mockBillingDAOServices);
		EasyMock.expect(mockBillingDAOServices.getMonthlyBill(EasyMock.isA(Long.class), EasyMock.isA(String.class)));
		EasyMock.replay(mockBillingDAOServices);
		EasyMock.expect(mockBillingDAOServices.deleteByMobileNo(700430840));
		EasyMock.replay(mockBillingDAOServices);
		EasyMock.expect(mockPostpaidAccountDAOService.removeMobileNo(700430840));
		EasyMock.replay(mockPostpaidAccountDAOService);
		/*EasyMock.expect(mockCustomerDAOService.deleteById(EasyMock.isA(Integer.class)));
		EasyMock.replay(mockCustomerDAOService);*/
		
	}
	@After
	public void tearDown() throws Exception {
	}
	@Test
	public final void testGetPlanAllDetails() throws PlanDetailsNotFoundException, BillingServicesDownException{
			List<Plan> plansActual = billingServicesPlan.getPlanAllDetails();
			assertEquals(plans,plansActual);
	}
	@Test
	public final void testAcceptCustomerDetails() throws BillingServicesDownException {
		int expectedCustomerID = 1001;		
		int actualCustomerID=billingServicesCustomer.acceptCustomerDetails(customer);
		assertEquals(expectedCustomerID, actualCustomerID);
	}
	@Test
	public final void testOpenPostpaidMobileAccount() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		long expectedMobileNo = 900000001;
		long actualMobileNo= billingServicesPostpaid.openPostpaidMobileAccount(customer.getCustomerID(),plan1.getPlanID());
		assertEquals(expectedMobileNo, actualMobileNo);
	}
	@Test(expected=CustomerDetailsNotFoundException.class)
	public final void testOpenPostpaidMobileAccountFail() throws CustomerDetailsNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException{
		long expectedMobileNo = 900000001;
		Plan plan1=new Plan(150, 100, 100, 100, 100, 1024, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f, "bihar/jharkhand", "Diwali offer");
		long actualMobileNo = billingServicesPostpaid.openPostpaidMobileAccount(100,plan1.getPlanID());
		assertEquals(expectedMobileNo, actualMobileNo);
	}
	@Test
	public final void testGenerateMonthlyMobileBill() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillingServicesDownException, PlanDetailsNotFoundException {
		int expectedTotalBill=150;
		int actualTotalAmount=billingServicesBill.generateMonthlyMobileBill(1001, 900000001," January", 100, 100, 100, 100, 1000);
		assertEquals(expectedTotalBill, actualTotalAmount);
	}
	@Test
	public final void testGetCustomerDetails() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer actual=billingServicesCustomer.getCustomerDetails(1001);
		Customer expected=new Customer(1001, "Sushant", "Dey", "sushant@gmail.com", "15-04-1996", null, null);
		assertEquals(expected, actual);
	}
	@Test
	public final void testGetAllCustomerDetails() throws BillingServicesDownException {
		List<Customer> expectedCustomers = customers;
		List<Customer>actualCustomers = billingServicesCustomer.getAllCustomerDetails();
		assertEquals(expectedCustomers, actualCustomers);
	}
	@Test
	public final void testGetCustomerAllPostpaidAccountsDetails() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		List<PostpaidAccount> expectedPostpaidAccounts = (List<PostpaidAccount>) customer.getPostpaidAccounts();
		List<PostpaidAccount> actualPostpaidAccounts = billingServicesCustomer.getCustomerAllPostpaidAccountsDetails(1001);
		assertEquals(expectedPostpaidAccounts, actualPostpaidAccounts);
	}

	@Test
	public final void testGetMobileBillDetails() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
		Bill expectedBill = bill1;
		Bill actualBill = billingServicesBill.getMobileBillDetails(1001, 700430840, "January");
		assertEquals(expectedBill, actualBill);
	}

	@Test
	public final void testGetCustomerPostPaidAccountAllBillDetails() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, BillDetailsNotFoundException, PlanDetailsNotFoundException {
		List<Bill> expectedBills = (List<Bill>) bills1;
		List<Bill> actualBills = billingServicesBill.getCustomerPostPaidAccountAllBillDetails(1001, 700430840);
		assertEquals(expectedBills, actualBills);
	}

	@Test
	public final void testChangePlan() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		int expected = 1;
		int actual = billingServicesPostpaid.changePlan(1001, 700430840, 2);
		assertEquals(expected, actual);
	}

	@Test
	public final void testCloseCustomerPostPaidAccount() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
		boolean expected = true;
		boolean actual = billingServicesPostpaid.closeCustomerPostPaidAccount(1001, 700430840);
		assertEquals(expected, actual);
	}

	@Test
	public final void testDeleteCustomer() throws BillingServicesDownException, CustomerDetailsNotFoundException {
		boolean expected = true;
		boolean actual = billingServicesCustomer.deleteCustomer(1001);
		assertEquals(expected, actual);
	}

	@Test
	public final void testGetCustomerPostPaidAccountPlanDetails() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
		Plan expectedPlan = plan2;
		Plan actualPlan = billingServicesCustomer.getCustomerPostPaidAccountPlanDetails(1001, 700430840);
		assertEquals(expectedPlan, actualPlan);
	}

}
