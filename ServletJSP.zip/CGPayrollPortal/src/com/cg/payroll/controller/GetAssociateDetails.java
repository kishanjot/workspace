package com.cg.payroll.controller;
import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

@WebServlet("/associateDetails")
public class GetAssociateDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PayrollServices services;
	public void init(ServletConfig config) throws ServletException {
		services=new PayrollServicesImpl();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Associate associate = null;

		try {
			associate=services.getAssociateDetails(Integer.parseInt(request.getParameter("associateId")));
			request.setAttribute("associate", associate);
			request.getRequestDispatcher("associateDetails.jsp").forward(request, response);
		} catch (AssociateDetailsNotfoundException e) {
			request.setAttribute("exception",e.getMessage());
			request.getRequestDispatcher("associateDetails.jsp").forward(request, response);
		}
	}
	public void destroy() {
		services=null;
	}
}
