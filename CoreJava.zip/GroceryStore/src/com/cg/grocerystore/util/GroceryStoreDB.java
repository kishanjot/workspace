package com.cg.grocerystore.util;

public class GroceryStoreDB {

}
