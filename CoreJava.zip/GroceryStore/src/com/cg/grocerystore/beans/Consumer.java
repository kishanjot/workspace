package com.cg.grocerystore.beans;

public class Consumer {
String fName;
String lName;
int mobileNo;
String address;
String occupation;

}
