package com.cg.grocerystore.beans;

public class Order {

}
