package com.cg.grocerystore.main;

public class MainClass {

}
