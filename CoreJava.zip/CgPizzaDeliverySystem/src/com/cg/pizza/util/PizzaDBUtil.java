package com.cg.pizza.util;

import java.util.HashMap;
import java.util.Random;

import com.cg.pizza.beans.Customer;

public class PizzaDBUtil 
{
	public static HashMap<Long, Customer> customer = new HashMap<>();
	static long customerId =100;
	
	public static int orderId = 1000;
	
	public static long getCUSTOMER_ID()
	{
		return ++customerId;
	}
	public static int  getORDER_ID() 
	{
	     return ++orderId;	
	}
	
}
