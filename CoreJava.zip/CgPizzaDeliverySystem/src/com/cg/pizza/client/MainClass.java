package com.cg.pizza.client;

import com.cg.pizza.beans.Customer;
import com.cg.pizza.exceptions.InvalidEmailIdException;
import com.cg.pizza.exceptions.InvalidMobileNumberException;
import com.cg.pizza.services.PizzaServices;
import com.cg.pizza.services.PizzaServicesImpl;

public class MainClass {

	public static void main(String[] args) throws InvalidMobileNumberException, InvalidEmailIdException 
	{
		PizzaServices services=new PizzaServicesImpl();
		long customerId1=services.acceptCustomerDetails("Kishanjot", "Singh", "9888565231", "kj@gmail.com", "chd", "sec 35", 123654);
		long customerId2=services.acceptCustomerDetails("Honey", "Singh", "8888565231", "bad@gmail.com", "chd", "sec 35", 123654);
		System.out.println("customer id="+customerId1);
		System.out.println("customer id="+customerId2);
		System.out.println(services.showAllItems());
	}

}
