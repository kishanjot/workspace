
public class MainClass {

	public static void main(String[] args) {
		int num=100; //AutoBoxing
		Integer iob=num;
		
		int iob1=iob;
		System.out.println(iob);
		System.out.println(iob1);
		
		Integer iob2=104; //AutoUnboxing
		int num1=iob2;
		System.out.println(iob2);
		System.out.println(num1);
		
		
		
		
	
	}

}
