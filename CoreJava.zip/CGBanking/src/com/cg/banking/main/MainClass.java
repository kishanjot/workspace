package com.cg.banking.main;

import com.cg.banking.beans.Customer;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException {
		BankingServicesImpl bankingservices=new BankingServicesImpl();
		//Customer customer=new Customer();
		int customerId=bankingservices.acceptCustomerDetails("shyam", "prasad", "asd@aqs", "asd123", "hyd", "ts", 52042, "kurn", "ap", 1234);
		bankingservices.updateCustomerDetails("asd", "zx", "wfv", "asd2", "asd", "ijn", 14586, "enf", "xch", 50007);
		int customerId1=bankingservices.acceptCustomerDetails("asdf", "prasasad", "asd@daqs", "asd123", "hyd", "ts", 52042, "kurn", "ap", 12345);
		long accountNo=bankingservices.openAccount(customerId, "saving", 1000);
		long accountNo1=bankingservices.openAccount(customerId1, "current", 2000);
		System.out.println(accountNo);
		System.out.println(customerId);
		System.out.println(accountNo1);
		System.out.println(customerId1);
		for (Customer customer :bankingservices.getAllCustomerDetails() ) {
			System.out.println(customer);
		}
	
	}
}
