package com.cg.equalsmethoddemo.main;
import com.cg.equalsmethoddemo.beans.Employee;

public class MainClass {
public static void main(String args[]) {
	Employee emp1=new Employee("Kishanjot", "Singh", 777);
	Employee emp2=new Employee("Kishanjot", "Singh", 777);
	
	Object obj=emp2; //it'll go to the methods which we created (hash code and equals) 
	
	if(emp1.equals(emp2)) 
	System.out.println(emp1.equals(emp2));
	if(obj.equals(emp2))
	System.out.println(obj.equals(emp2));
}
}
