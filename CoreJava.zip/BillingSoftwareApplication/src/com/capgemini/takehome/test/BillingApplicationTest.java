//-----TEST CASE FOR BILLING APPLICATION--//

package com.capgemini.takehome.test;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exceptions.InvalidCodeException;
import com.capgemini.takehome.exceptions.ProductNotFoundException;
import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;
import com.capgemini.takehome.util.CollectionUtil;



public class BillingApplicationTest {
	private static IProductService services;
	@BeforeClass
	public static void setUpTestEnv() { 	//Before Class For Setting Up The Env
		services=new ProductService();
	}
	@Before
	public void setUpTestData() {}
	@Test
	public void testGetProductDetailsForValidProductCode() throws InvalidCodeException {
		 Product expectedProduct=new Product(1001,"iPhone","Electronics",35000);
		 Product actualProduct=services.getProductDetails(1001);
	    Assert.assertEquals(expectedProduct, actualProduct);
	}
	@Test(expected=ProductNotFoundException.class)
	public void testProductNotFoundDetails() throws ProductNotFoundException {
		services.getProductDetails(1445);
		
	}
	@After
	public void tearDownTestData() {
		CollectionUtil.products.clear(); //Cleared

	}
	@AfterClass
	public static void tearDownEnv() {		//Destroyed
		services=null;
	}
}

