package com.capgemini.takehome.exceptions;
public class ProductNotFoundException extends RuntimeException {
}
