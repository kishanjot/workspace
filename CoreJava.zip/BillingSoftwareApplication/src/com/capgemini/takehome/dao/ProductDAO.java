package com.capgemini.takehome.dao;
import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.util.CollectionUtil;
public class ProductDAO implements IProductDAO {
	public Product getProductDetails(int productCode) {
		return CollectionUtil.products.get(productCode);
	}

	@Override
	public Product save(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

}
