class HelloWorldWithArgs
{
	public static void main(String args[])
	{
		System.out.println("Hello " + args[0]);
	}
}