package com.cg.project.staticinnerdemo;
public class MainClass {
	public static void main(String[] args) {
		HotelClass.VegKitchen vegKitchen=new HotelClass.VegKitchen();
		HotelClass.NonVegKitchen nonVegKitchen=new HotelClass.NonVegKitchen();
	}
}

