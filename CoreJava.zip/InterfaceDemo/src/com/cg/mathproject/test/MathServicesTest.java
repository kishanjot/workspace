package com.cg.mathproject.test;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.mathproject.exceptions.NegativeNumberException;
import com.cg.mathproject.services.MathServices;
import com.cg.mathproject.services.MathServicesImpl;

public class MathServicesTest {
	private static MathServices services;
	@BeforeClass
	public static void setUpTestEnv() {
		services=new MathServicesImpl();
		}
	
	@Test(expected=NegativeNumberException.class)
	public void testAddForFirstNumberInvalid() throws NegativeNumberException{
		services.add(-100, 200);
	}
	@Test(expected=NegativeNumberException.class)
	public void testAddForSecondNumberInvalid() throws NegativeNumberException{
		services.add(100, -200);
	}
	@Test
	public void testAddForBothValidNumber() throws NegativeNumberException{
		Assert.assertEquals(300, services.add(100, 200));
	}
	@Test(expected=NegativeNumberException.class)
	public void testSubForFirstNumberInvalid() throws NegativeNumberException{
		services.sub(-100, 200);
	}
	@Test(expected=NegativeNumberException.class)
	public void testSubForSecondNumberInvalid() throws NegativeNumberException{
		services.sub(100, -200);
	}
	@Test
	public void testSubForBothValidNumber() throws NegativeNumberException{
		Assert.assertEquals(300, services.sub(500, 200));
	}
	@Test(expected=NegativeNumberException.class)
	public void testDivForFirstNumberInvalid() throws NegativeNumberException{
		services.div(-100, 200);
	}
	@Test(expected=NegativeNumberException.class)
	public void testDivForSecondNumberInvalid() throws NegativeNumberException{
		services.div(100, -200);
	}
	@Test
	public void testDivForBothValidNumber() throws NegativeNumberException{
		Assert.assertEquals(3, services.div(600, 200));
	}
	@Test(expected=NegativeNumberException.class)
	public void testMulForFirstNumberInvalid() throws NegativeNumberException{
		services.mul(-100, 200);
	}
	@Test(expected=NegativeNumberException.class)
	public void testMulForSecondNumberInvalid() throws NegativeNumberException{
		services.mul(100, -200);
	}
	@Test
	public void testMulForBothValidNumber() throws NegativeNumberException{
		Assert.assertEquals(600, services.mul(30, 20));
	}
	@AfterClass
	public static void tearDownTestEnv() {
		services=null;
	}
}
