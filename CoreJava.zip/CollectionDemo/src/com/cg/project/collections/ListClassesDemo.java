package com.cg.project.collections;

import java.util.ArrayList;
import java.util.Collections;

import com.cg.project.beans.Associate;
import com.cg.project.client.MainClass;

public class ListClassesDemo{
public static void arrayListClassDemo() {

	ArrayList<String> strList=new ArrayList<>();
	
	strList.add("Kishan");
	strList.add("Joey");
	strList.add("Honey");
	strList.add("Brad");
	strList.add("Chad");
	strList.add("Kishan");
	strList.add("Jaspreet");
	
	System.out.println(strList);
	
	//search
	
	String nameToBeSearch="Honey";
	System.out.println(strList.contains(nameToBeSearch));
	System.out.println(strList.indexOf(nameToBeSearch));
	System.out.println(strList.indexOf("Kishan"));
	
	int index=strList.indexOf(nameToBeSearch);
	System.out.println(strList.get(index));
	ArrayList<Associate>associates=new ArrayList<>();
	associates.add(new Associate(111,"Kishan","Jot",1500));
	associates.add(new Associate(113,"Honey","Singh",1700));
	associates.add(new Associate(112,"Brad","Chad",1600));
	associates.add(new Associate(117,"Kishan","Jot",1400));

	//Associate associateToBeSearch= new Associate(112,"Brad","Chad",1600);
	//System.out.println(associates.contains(associateToBeSearch));
	//sorting
	//Collections.sort(associates);
	
	//for(Associate associate:associates)
	//{
		System.out.println(associates.toString());
		System.out.println(associates.contains(new Associate(113,"Honey","Singh",1700)));
	//}
	//System.out.println("================");
	//Collections.sort(associate,new AssociateComparator());
	
	//for(Associate associates:associate)
	{
		System.out.println(associates);
	}
}

}
