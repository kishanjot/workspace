package com.cg.project.collections;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Set;

import com.cg.project.beans.Associate;
public class MapClassesDemo {
	public static void MapClassesDemo() {
		Hashtable<Integer,Associate> associates=new Hashtable<>();
		associates.put(111,new Associate(111,"Kishan","Jot",1500));
		associates.put(113,new Associate(113,"Honey","Singh",1700));
		associates.put(112,new Associate(112,"Brad","Chad",1600));
		associates.put(117,new Associate(117,"Kishan","Jot",1400));
		
		Associate associate=associates.get(112);
		associates.remove(112);
		Set<Integer>keys=associates.keySet();
		for(Integer key:keys) {
			System.out.println(associates.get(key));
		}
		ArrayList<Associate>associatesList=new ArrayList<>(associates.values());
	}

}
