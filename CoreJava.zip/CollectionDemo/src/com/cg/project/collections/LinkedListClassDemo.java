package com.cg.project.collections;

public class LinkedListClassDemo {

}
