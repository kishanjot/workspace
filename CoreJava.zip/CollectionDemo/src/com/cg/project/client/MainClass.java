package com.cg.project.client;

import com.cg.project.collections.ListClassesDemo;

public class MainClass {
	public static void main(String[] args) {
		ListClassesDemo.arrayListClassDemo();
		
	}

}
