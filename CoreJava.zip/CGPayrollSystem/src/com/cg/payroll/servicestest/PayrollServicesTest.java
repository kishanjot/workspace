package com.cg.payroll.servicestest;
import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;
public class PayrollServicesTest {
	private static PayrollServices services;
@BeforeClass
public static void setUpTestEnv() {
	services=new PayrollServicesImpl();
	}
@Before
public void setUpTestData() {
	Associate associate1=new Associate(101,78000,"Kishanjot","Singh","training", "Analyst", "GIYs234R","Kishanjot@gmail.com" ,new Salary(35000,1800,1800),new BankDetails(12345,"HDFC","HDFC05"));
	Associate associate2=new Associate(102,88000,"Honey","Singh","training", "Analyst", "HGDs234R","Honey@gmail.com" ,new Salary(25000,1800,1800),new BankDetails(22345,"HDFC","HDFC05"));	
			PayrollDBUtil.associates.put(associate1.getAssociateId(),associate1);
			PayrollDBUtil.associates.put(associate2.getAssociateId(),associate2);
			PayrollDBUtil.ASSOCIATE_ID_COUNTER=102;
}

@Test(expected=AssociateDetailsNotfoundException.class)
public void testGetAssociateDetailsForInvalidAssociateId() throws AssociateDetailsNotfoundException {
    services.getAssociateDetails(12345);
}
@Test
public void testGetAssociateDetailsForValidAssociateId() throws AssociateDetailsNotfoundException {
    Associate expectedAssociate=new Associate(102,88000,"Honey","Singh","training", "Analyst", "HGDs234R","Honey@gmail.com" ,new Salary(25000,1800,1800),new BankDetails(22345,"HDFC","HDFC05"));	
    Associate actualAssociate=services.getAssociateDetails(102);
    Assert.assertEquals(expectedAssociate, actualAssociate);
}
@Test
public void testAcceptAssociateDetailsForValidData() throws AssociateDetailsNotfoundException {
    int expectedId=103;
    int actualId=services.acceptAssociateDetails("ABD","singh", "adsafd","dsfsf","fsf", "fdsf",24323, 213213,1000, 2232, 234324, "jlkds","hkjw");
    Assert.assertEquals(expectedId, actualId);
}
@Test(expected=AssociateDetailsNotfoundException.class)
public void testCalCulateNetSalaryForInvalidAssociateId() throws AssociateDetailsNotfoundException {
    services.calculateNetSalary(1234);
}
@Test
public void testCalculateNetSalaryForValidAssociateId() throws AssociateDetailsNotfoundException {
    int expectedNetSalary=0;
    int actualNetSalary=services.calculateNetSalary(102);
    Assert.assertEquals(expectedNetSalary, actualNetSalary);
}
@Test
public void testgetAllAssociateDetails() throws AssociateDetailsNotfoundException{
	Associate associate1=new Associate(101,78000,"Kishanjot","Singh","training", "Analyst", "GIYs234R","Kishanjot@gmail.com" ,new Salary(35000,1800,1800),new BankDetails(12345,"HDFC","HDFC05"));
	Associate associate2=new Associate(102,88000,"Honey","Singh","training", "Analyst", "HGDs234R","Honey@gmail.com" ,new Salary(25000,1800,1800),new BankDetails(22345,"HDFC","HDFC05"));	
    ArrayList<Associate>expectedList=new ArrayList<>();
    expectedList.add(associate1);
    expectedList.add(associate2);
    ArrayList<Associate>actualList=(ArrayList<Associate>) services.getAllAssociatesDetails();
}






@After
public void tearDownTestData() {
	PayrollDBUtil.associates.clear();
	PayrollDBUtil.ASSOCIATE_ID_COUNTER=100;
}


@AfterClass
public static void tearDownEnv() {
	services=null;
	}
}
