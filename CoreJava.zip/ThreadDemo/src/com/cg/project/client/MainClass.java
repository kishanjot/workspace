package com.cg.project.client;
import com.cg.project.threadwork.RunnableResource;
public class MainClass {
	public static void main(String[] args) throws InterruptedException {

		RunnableResource resource=new RunnableResource();
		Thread th1=new Thread(resource,"tickThread"); 	//thread born
		Thread th2=new Thread(resource,"tockThread");
		//Thread th1=new Thread(resource,"Number");
		//Thread th2=new Thread(resource,"Prime");
		th1.start(); //eligible for execution
		th1.join();
		th2.start();
		//th2.join();
		System.out.println("Main thread ends here");
	}
}
