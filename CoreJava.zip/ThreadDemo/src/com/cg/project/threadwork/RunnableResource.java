package com.cg.project.threadwork;
public class RunnableResource implements Runnable {
	@Override
	public void run() {
		//boolean flag = false;
		Thread t=Thread.currentThread();
		if(t.getName().equals("tickThread")) {
			try {
				for(int i=1;i<=10;i++) {
					Thread.sleep(1000);
					System.out.println("Tick "+i+" "+t.getName());
				}
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
		}

		if(t.getName().equals("tockThread")){
			try {
				for(int i=1;i<=10;i++) {
					Thread.sleep(1000);
					System.out.println("Tock "+i+" "+t.getName());
				}
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
		/*
		 if(t.getName().equals("Number"))
				for(int i=1;i<=100;i++) {
					if(i%2==0)
						System.out.println("Even Number" +i);
					else
						System.out.println("Odd Number"+i);
				}

		 if(t.getName().equals("Prime"))
				for(int i=2;i<=100;i++) {
					for(int j=3;j<=i/2;j++) 
					if(i% j==0) {
					 flag = true;
		                break;}
		        if (!flag)
		            System.out.println(i+ " is a prime number.");
		        else
		            System.out.println(i+ " is not a prime number.");

				}
		 */


		System.out.println("End of Thread Task");
	}
}
