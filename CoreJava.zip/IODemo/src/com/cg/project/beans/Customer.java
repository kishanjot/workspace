package com.cg.project.beans;
import java.io.Serializable;

public class Customer implements Serializable {
private static int CUSTOMER_ID_COUNTER=100;
private int custId;
private String fName,lName;
private transient Address address;
public Customer() {}
public Customer(int custId, String fName, String lName, Address address) {
	super();
	this.custId = custId;
	this.fName = fName;
	this.lName = lName;
	this.address = address;
}

public int getCustId() {
	return custId;
}

public void setCustId(int custId) {
	this.custId = custId;
}

public String getfName() {
	return fName;
}

public void setfName(String fName) {
	this.fName = fName;
}

public String getlName() {
	return lName;
}

public void setlName(String lName) {
	this.lName = lName;
}

public Address getAddress() {
	return address;
}

public void setAddress(Address address) {
	this.address = address;
}

	
}
