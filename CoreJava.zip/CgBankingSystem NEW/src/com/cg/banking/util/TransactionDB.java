package com.cg.banking.util;
import com.cg.banking.beans.Account;

import java.util.ArrayList;
import java.util.HashMap;
import com.cg.banking.beans.Transaction;
public class TransactionDB {
	private static int transasctionID=999;
	public static int getTransactionID(){
		return ++transasctionID;
	}
}
