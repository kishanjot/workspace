import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class MainClass {
public static void main(String[] args) {
		method1();
	}
	public static void method1() {
		String str="Hell23o Welcome3 To Jav4a Trainin3g";
		Pattern pattern=Pattern.compile("\\D+");
		Matcher matcher=pattern.matcher(str);
		while(matcher.find()) {
			System.out.println(matcher.start()+" "+matcher.end()+" " +matcher.group());
		}
	}
	public static void method2() {
		String str="Hell23o Welcome3 To Jav4a Trainin3g";
		Pattern pattern=Pattern.compile("\\s"); //calc white spaces
		Matcher matcher=pattern.matcher(str);
		while(matcher.find()) {
			System.out.println(matcher.start()+" "+matcher.end()+" " +matcher.group());
		}
	}
	public static void method3() {
		String str="Hell23o Welcome3 To Jav4a Trainin3g";
		Pattern pattern=Pattern.compile("\\D?");
		Matcher matcher=pattern.matcher(str);
		while(matcher.find()) {
			System.out.println(matcher.start()+" "+matcher.end()+" " +matcher.group());
		}
	}
}
