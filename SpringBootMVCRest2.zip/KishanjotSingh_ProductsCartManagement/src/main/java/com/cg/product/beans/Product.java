//BeanClass

package com.cg.product.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity  //It will create table - Product
public class Product {
@Id
private String id;

private	String name;
private String model;
private int price;

public Product() {} //default constructor

//parameterised constructor without ID
public Product(String name, String model, int price) {
	super();
	this.name = name;
	this.model = model;
	this.price = price;
}
//parameterised constructor with ID

public Product(String id, String name, String model, int price) {
	super();
	this.id = id;
	this.name = name;
	this.model = model;
	this.price = price;
}
public String getId() {		//GETTERS AND SETTERS
	return id;
}

public void setId(String id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getModel() {
	return model;
}

public void setModel(String model) {
	this.model = model;
}

public int getPrice() {
	return price;
}

public void setPrice(int price) {
	this.price = price;
}

@Override
public String toString() {
	return "Product [id=" + id + ", name=" + name + ", model=" + model + ", price=" + price + "]";
}



}
