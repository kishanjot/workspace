package com.cg.product.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.product.beans.Product;
import com.cg.product.daoservices.IProductRepo;
import com.cg.product.exceptions.ProductNotFoundInDatabaseException;

@Component()
public class IProductServiceImpl implements IProductService {
	@Autowired
	IProductRepo productRepo;
	
	@Override
	public Product createProduct(Product product) {
		product=productRepo.save(product);
		return product;
	}
	
	@Override
	public Product updateProduct(Product product) throws ProductNotFoundInDatabaseException {
		return productRepo.save(product);
	}
	
	@Override
	public List<Product> viewProducts() {
		return productRepo.findAll();
	}
	@Override
	public boolean deleteProduct(String productId) throws ProductNotFoundInDatabaseException {
		findProduct(productId);
		productRepo.delete(findProduct(productId));
		return true;
	}
	@Override
	public Product findProduct(String productId) throws ProductNotFoundInDatabaseException {
		return productRepo.findById(productId).orElseThrow(()-> new ProductNotFoundInDatabaseException("Prod Not Found"));
	}
}