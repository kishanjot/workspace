package com.cg.product.services;
import java.util.List;


import com.cg.product.beans.Product;
import com.cg.product.exceptions.ProductNotFoundInDatabaseException;

public interface IProductService {
public Product createProduct(Product product);
public Product updateProduct(Product product) throws ProductNotFoundInDatabaseException;
public boolean deleteProduct(String productId) throws ProductNotFoundInDatabaseException;
public List<Product> viewProducts();
public Product findProduct(String productId) throws ProductNotFoundInDatabaseException;
//boolean deleteProductDetails(int productId)throws ProductNotFoundInDatabaseException;
}