package com.cg.pizza.services;

import java.util.List;

import com.cg.pizza.beans.Pizza;
import com.cg.pizza.beans.Restaurant;
import com.cg.pizza.exceptions.PizzaNotFoundException;
import com.cg.pizza.exceptions.RestaurantNotFoundException;

public interface PizzaServices{

	public Restaurant acceptRestaurantDetails(Restaurant restaurant);
	public Restaurant getRestaurantDetails(int rId) throws RestaurantNotFoundException; 
	public Pizza acceptPizzaDetails(Pizza pizza); 
	public Pizza getPizzaDetails(int pizzaId) throws PizzaNotFoundException;
	public List<Pizza> getAllPizzaDetails();
	boolean removePizzaDetails(int pizzaId)throws PizzaNotFoundException;
	boolean removeRestaurantDetails(int rId)throws RestaurantNotFoundException;
}
