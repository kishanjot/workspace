package com.cg.pizza.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Restaurant {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int rId;
	private String rName;
	private String rOwner;
	
	@OneToMany(mappedBy="restaurant")
	private List<Pizza> pizzas;
	
	public Restaurant() {}

	public Restaurant(String rName, String rOwner, List<Pizza> pizzas) {
		super();
		this.rName = rName;
		this.rOwner = rOwner;
		this.pizzas = pizzas;
	}

	public Restaurant(int rId, String rName, String rOwner, List<Pizza> pizzas) {
		super();
		this.rId = rId;
		this.rName = rName;
		this.rOwner = rOwner;
		this.pizzas = pizzas;
	}

	public int getrId() {
		return rId;
	}

	public void setrId(int rId) {
		this.rId = rId;
	}

	public String getrName() {
		return rName;
	}

	public void setrName(String rName) {
		this.rName = rName;
	}

	public String getrOwner() {
		return rOwner;
	}

	public void setrOwner(String rOwner) {
		this.rOwner = rOwner;
	}

	public List<Pizza> getPizzas() {
		return pizzas;
	}

	public void setPizzas(List<Pizza> pizzas) {
		this.pizzas = pizzas;
	}

	@Override
	public String toString() {
		return "Restaurant [rId=" + rId + ", rName=" + rName + ", rOwner=" + rOwner + ", pizzas=" + pizzas + "]";
	}
	
}
