package com.cg.pizza.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.pizza.beans.Restaurant;

public interface RestaurantDao extends JpaRepository<Restaurant,Integer> {

}
