package com.cg.pizza.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.pizza.beans.Pizza;
import com.cg.pizza.beans.Restaurant;
import com.cg.pizza.exceptions.PizzaNotFoundException;
import com.cg.pizza.exceptions.RestaurantNotFoundException;
import com.cg.pizza.services.PizzaServices;

@Controller
public class PizzaServicesControllers {

	@Autowired
	PizzaServices pizzaServices;
	
	@RequestMapping(value= {"/getRestaurantDetails"},method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Restaurant> getRestaurantDetailsDetailsRequestParam(@RequestParam int rId) throws RestaurantNotFoundException{
		Restaurant restaurant=pizzaServices.getRestaurantDetails(rId);
		return new ResponseEntity<Restaurant>(restaurant,HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/getPizzaDetails"},method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Pizza> getPizzaDetailsDetailsRequestParam(@RequestParam int pizzaId) throws PizzaNotFoundException{
		Pizza pizza=pizzaServices.getPizzaDetails(pizzaId);
		return new ResponseEntity<Pizza>(pizza,HttpStatus.OK);
	}
	

	@RequestMapping(value="/acceptRestaurantDetails",method=RequestMethod.POST, 
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptMovieDetails(@ModelAttribute Restaurant restaurant){
		restaurant=pizzaServices.acceptRestaurantDetails(restaurant);
		return new ResponseEntity<>("Restaurant details successfully added with ID:- "+restaurant.getrId(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/acceptPizzaDetails",method=RequestMethod.POST, 
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptPizzaDetails(@ModelAttribute Pizza pizza){
		pizza=pizzaServices.acceptPizzaDetails(pizza);
		return new ResponseEntity<>("Pizza details successfully added with ID:- "+pizza.getPizzaId(),HttpStatus.OK);
	}
	
	@RequestMapping(value="/removeRestaurantDetails",method=RequestMethod.DELETE, 
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> removeRestaurantDetails(@RequestParam int rId)throws RestaurantNotFoundException{
		pizzaServices.removeRestaurantDetails(rId);
		return new ResponseEntity<>("Restaurant details successfully removed ",HttpStatus.OK);
	}
	
	@RequestMapping(value="/removePizzaDetails",method=RequestMethod.DELETE, 
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> removePizzaDetails(@RequestParam int pizzaId)throws PizzaNotFoundException{
		pizzaServices.removePizzaDetails(pizzaId);
		return new ResponseEntity<>("Pizza details successfully removed ",HttpStatus.OK);
	}
	
	@RequestMapping(value="/AllPizzaDetails",method=RequestMethod.GET, 
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<List<Pizza>>getRestaurantDetailsPathParam(){
		return new ResponseEntity<List<Pizza>>(pizzaServices.getAllPizzaDetails(),HttpStatus.OK);
	}
	
}
