package com.cg.pizza.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.pizza.beans.Pizza;
import com.cg.pizza.beans.Restaurant;
import com.cg.pizza.daoservices.PizzaDao;
import com.cg.pizza.daoservices.RestaurantDao;
import com.cg.pizza.exceptions.PizzaNotFoundException;
import com.cg.pizza.exceptions.RestaurantNotFoundException;

@Component
public class PizzaServicesImpl implements PizzaServices{
	@Autowired
	PizzaDao pizzaDao;
	@Autowired
	RestaurantDao restaurantDao;
	
	@Override
	public Restaurant acceptRestaurantDetails(Restaurant restaurant) {
	
		return restaurantDao.save(restaurant);
	}

	@Override
	public Restaurant getRestaurantDetails(int rId) throws RestaurantNotFoundException {
		
		return restaurantDao.findById(rId).orElseThrow(()->new RestaurantNotFoundException("Rest Not Found"));
	}

	@Override
	public Pizza acceptPizzaDetails(Pizza pizza) {
		
		return pizzaDao.save(pizza);
	}

	@Override
	public Pizza getPizzaDetails(int pizzaId) throws PizzaNotFoundException {
		
		return pizzaDao.findById(pizzaId).orElseThrow(()-> new PizzaNotFoundException("Pizza Not Found"));
	}

	@Override
	public List<Pizza> getAllPizzaDetails() {
		
		return pizzaDao.findAll();
	}

	@Override
	public boolean removePizzaDetails(int pizzaId) throws PizzaNotFoundException {
		
		pizzaDao.delete(getPizzaDetails(pizzaId));
		return true;
	}

	@Override
	public boolean removeRestaurantDetails(int rId) throws RestaurantNotFoundException {
		restaurantDao.delete(getRestaurantDetails(rId));
		return true;
	}

}
