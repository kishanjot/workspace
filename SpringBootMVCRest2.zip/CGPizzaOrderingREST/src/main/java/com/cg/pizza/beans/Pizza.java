package com.cg.pizza.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Pizza {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int pizzaId;
	private String pizzaName;
	private String pizzaToppings;
	
	@JsonIgnore
	@OneToOne
	private Restaurant restaurant;
	
	public Pizza() {}
	public Pizza(String pizzaName, String pizzaToppings, Restaurant restaurant) {
		super();
		this.pizzaName = pizzaName;
		this.pizzaToppings = pizzaToppings;
		this.restaurant = restaurant;
	}
	public Pizza(int pizzaId, String pizzaName, String pizzaToppings, Restaurant restaurant) {
		super();
		this.pizzaId = pizzaId;
		this.pizzaName = pizzaName;
		this.pizzaToppings = pizzaToppings;
		this.restaurant = restaurant;
	}
	public int getPizzaId() {
		return pizzaId;
	}
	public void setPizzaId(int pizzaId) {
		this.pizzaId = pizzaId;
	}
	public String getPizzaName() {
		return pizzaName;
	}
	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}
	public String getPizzaToppings() {
		return pizzaToppings;
	}
	public void setPizzaToppings(String pizzaToppings) {
		this.pizzaToppings = pizzaToppings;
	}
	public Restaurant getRestaurant() {
		return restaurant;
	}
	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}
	@Override
	public String toString() {
		return "Pizza [pizzaId=" + pizzaId + ", pizzaName=" + pizzaName + ", pizzaToppings=" + pizzaToppings
				+ ", restaurant=" + restaurant + "]";
	}

	
}
