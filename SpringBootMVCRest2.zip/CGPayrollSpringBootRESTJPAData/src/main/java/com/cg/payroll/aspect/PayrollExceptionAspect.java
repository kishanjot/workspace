package com.cg.payroll.aspect;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import com.cg.payroll.exceptions.AssociateDetailsNotfoundException;
import com.cg.payroll.response.CustomResponse;
@ControllerAdvice
public class PayrollExceptionAspect {
	@ExceptionHandler(AssociateDetailsNotfoundException.class)
	public ResponseEntity<CustomResponse> handleAssociateDetailsNotFoundException(Exception e) {
		CustomResponse response=new CustomResponse(e.getMessage(), HttpStatus.EXPECTATION_FAILED.value());
		return new ResponseEntity<>(response,HttpStatus.EXPECTATION_FAILED);
	}
}